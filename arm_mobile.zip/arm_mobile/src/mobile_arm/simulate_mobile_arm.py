#!/usr/bin/env python3
"""
Enhanced PyBullet Mobile Arm Controller with SLAM and RViz Visualization

New Features:
- Continuous SLAM mapping while moving
- RViz visualization of map, path, and robot pose
- Adjustable obstacle sizes for arm grasping
- Real-time map updates during navigation
- TF broadcasting for robot pose

Controls:
    W/S: Move forward/backward
    A/D: Turn left/right
    I/K: Shoulder joint up/down
    J/L: Elbow joint up/down
    U/O: Wrist joint up/down
    M: Toggle autonomous mode (navigate to goal)
    R: Start/Stop SLAM recording
    V: Save and visualize current map
    G: Set new goal position
    Q: Quit

Usage:
    # Terminal 1: Start RViz
    rviz2 -d robot_slam.rviz
    
    # Terminal 2: Run simulator
    python3 enhanced_slam.py --urdf ~/arm_mobile/src/mobile_arm/urdf/mobile.urdf --goal 5.0 2.0 0
"""

import os
import sys
import time
import math
import random
import argparse
import json
import numpy as np
import cv2
from collections import deque
from pathlib import Path as PathLib  # Import with alias to avoid ROS conflict

# PyBullet
import pybullet as p
import pybullet_data

# ROS2
try:
    import rclpy
    from rclpy.node import Node
    from std_msgs.msg import Header, ColorRGBA
    from geometry_msgs.msg import PoseStamped, Point, Quaternion, TransformStamped
    from nav_msgs.msg import OccupancyGrid, MapMetaData, Odometry
    from nav_msgs.msg import Path as NavPath  # Renamed to avoid conflict
    from sensor_msgs.msg import PointCloud2, PointField, Image
    from visualization_msgs.msg import Marker, MarkerArray
    from tf2_ros import TransformBroadcaster
    from cv_bridge import CvBridge
    import sensor_msgs_py.point_cloud2 as pc2
    ROS_AVAILABLE = True
except ImportError:
    ROS_AVAILABLE = False
    print("ROS2 not available - running without ROS support")

# -----------------------
# Utilities
# -----------------------
def euler_to_quat(roll, pitch, yaw):
    """Convert Euler angles to quaternion (x,y,z,w)"""
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    w = cr * cp * cy + sr * sp * sy
    x = sr * cp * cy - cr * sp * sy
    y = cr * sp * cy + sr * cp * sy
    z = cr * cp * sy - sr * sp * cy
    return (x, y, z, w)

def quat_to_euler(q):
    """Convert quaternion to Euler angles (roll, pitch, yaw)"""
    x, y, z, w = q
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(t0, t1)
    
    t2 = +2.0 * (w * y - z * x)
    t2 = max(-1.0, min(1.0, t2))
    pitch = math.asin(t2)
    
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(t3, t4)
    return (roll, pitch, yaw)

# -----------------------
# Environment Creation
# -----------------------
def create_room_env(pclient, graspable_box_size=0.15):
    """Create environment with adjustable obstacle sizes"""
    room_w = 8
    room_h = 8
    wall_thickness = 0.2
    wall_height = 2.5
    door_width = 2

    def create_wall(x, y, z, lx, ly, lz, color=[0.8, 0.8, 0.8]):
        col = p.createCollisionShape(p.GEOM_BOX, halfExtents=[lx/2, ly/2, lz/2])
        vis = p.createVisualShape(p.GEOM_BOX, halfExtents=[lx/2, ly/2, lz/2], 
                                  rgbaColor=color + [1])
        body_id = p.createMultiBody(baseMass=0, baseCollisionShapeIndex=col, 
                         baseVisualShapeIndex=vis, basePosition=[x, y, z])
        return body_id

    def create_room(center_x, center_y, with_door=False, door_side="right"):
        create_wall(center_x, center_y + room_h/2, wall_height/2, 
                   room_w, wall_thickness, wall_height)
        create_wall(center_x, center_y - room_h/2, wall_height/2, 
                   room_w, wall_thickness, wall_height)

        if not (with_door and door_side == "left"):
            create_wall(center_x - room_w/2, center_y, wall_height/2, 
                       wall_thickness, room_h, wall_height)
        else:
            create_wall(center_x - room_w/2, center_y + door_width, wall_height/2, 
                       wall_thickness, room_h - door_width, wall_height)

        if not (with_door and door_side == "right"):
            create_wall(center_x + room_w/2, center_y, wall_height/2, 
                       wall_thickness, room_h, wall_height)
        else:
            gap_half = door_width / 2
            create_wall(center_x + room_w/2, center_y + (room_h/2 - gap_half), 
                       wall_height/2, wall_thickness, (room_h/2 - gap_half), wall_height)
            create_wall(center_x + room_w/2, center_y - (room_h/2 - gap_half), 
                       wall_height/2, wall_thickness, (room_h/2 - gap_half), wall_height)

    create_room(-5, 0, with_door=True, door_side="right")
    create_room(5, 0, with_door=True, door_side="left")

    def create_box(x, y, z, size=0.4, color=[0.6, 0.4, 0.2], mass=1.0):
        col = p.createCollisionShape(p.GEOM_BOX, halfExtents=[size/2]*3)
        vis = p.createVisualShape(p.GEOM_BOX, halfExtents=[size/2]*3, 
                                 rgbaColor=color + [1])
        body_id = p.createMultiBody(baseMass=mass, baseCollisionShapeIndex=col, 
                         baseVisualShapeIndex=vis, basePosition=[x, y, z])
        return body_id

    def create_rack(x, y, shelves=3):
        for i in range(shelves):
            create_box(x, y, 0.3 + i*0.6, size=1.0, color=[0.7, 0.7, 0.7], mass=0)

    # Add racks
    for i in range(3):
        create_rack(-6, -2 + i*2.5)
        create_rack(6, -2 + i*2.5)

    # Add graspable objects (smaller boxes)
    graspable_objects = []
    print(f"\nCreating graspable objects (size: {graspable_box_size}m)")
    for i in range(8):
        bx = random.uniform(-7, 7)
        by = random.uniform(-3, 3)
        box_id = create_box(bx, by, graspable_box_size/2, 
                           size=graspable_box_size, 
                           color=[0.8, 0.3, 0.2],
                           mass=0.5)
        graspable_objects.append(box_id)
    
    # Add fixed obstacles
    for _ in range(7):
        bx = random.uniform(-7, 7)
        by = random.uniform(-3, 3)
        create_box(bx, by, 0.2, size=random.uniform(0.3, 0.5), mass=0)
    
    return graspable_objects

# -----------------------
# Camera and Mapping
# -----------------------
def get_camera_image_from_link(client, robot_id, link_name, img_w=320, img_h=240, 
                               fov=60, near=0.01, far=5.0):
    """Render RGB-D image from a specific link"""
    link_idx = None
    for i in range(p.getNumJoints(robot_id, physicsClientId=client)):
        info = p.getJointInfo(robot_id, i, physicsClientId=client)
        child_name = info[12].decode('utf-8')
        if child_name == link_name or link_name in child_name:
            link_idx = i
            break

    if link_idx is None:
        base_pos, base_orn = p.getBasePositionAndOrientation(robot_id, physicsClientId=client)
        cam_pos = base_pos
        cam_orn = base_orn
    else:
        state = p.getLinkState(robot_id, link_idx, computeForwardKinematics=True, 
                              physicsClientId=client)
        cam_pos = state[4]
        cam_orn = state[5]

    roll, pitch, yaw = quat_to_euler(cam_orn)
    cam_target = [cam_pos[0] + math.cos(yaw), cam_pos[1] + math.sin(yaw), cam_pos[2] - 0.05]
    up_vector = [0, 0, 1]
    
    view = p.computeViewMatrix(cam_pos, cam_target, up_vector)
    aspect = img_w / img_h
    proj = p.computeProjectionMatrixFOV(fov, aspect, near, far)
    
    img = p.getCameraImage(img_w, img_h, viewMatrix=view, projectionMatrix=proj, 
                          physicsClientId=client)
    width, height, rgb, depth, seg = img[0], img[1], img[2], img[3], img[4]
    
    rgb_arr = np.reshape(rgb, (height, width, 4))[:, :, :3].astype(np.uint8)
    depth_buffer = np.reshape(depth, (height, width))
    z = far * near / (far - (far - near) * depth_buffer)
    
    return rgb_arr, z, seg, (cam_pos, cam_orn)

def depth_to_pointcloud(depth_map, intrinsics):
    """Convert depth map to 3D point cloud in camera frame"""
    h, w = depth_map.shape
    i = np.arange(w)
    j = np.arange(h)
    u, v = np.meshgrid(i, j)
    z = depth_map
    valid = z > 0
    x = (u - intrinsics['cx']) * z / intrinsics['fx']
    y = (v - intrinsics['cy']) * z / intrinsics['fy']
    pts = np.stack([x, y, z], axis=-1)
    pts = pts[valid]
    return pts

def transform_pointcloud(pts, cam_pose):
    """Transform point cloud from camera frame to world frame"""
    pos, orn = cam_pose
    rot = p.getMatrixFromQuaternion(orn)
    R = np.array(rot).reshape(3, 3)
    pts_w = (R.dot(pts.T)).T + np.array(pos)
    return pts_w

# -----------------------
# Occupancy Grid Mapping with SLAM
# -----------------------
class OccupancyMap2D:
    def __init__(self, xmin=-10, xmax=10, ymin=-10, ymax=10, resolution=0.1):
        self.xmin, self.xmax = xmin, xmax
        self.ymin, self.ymax = ymin, ymax
        self.res = resolution
        self.nx = int(np.ceil((xmax - xmin) / resolution))
        self.ny = int(np.ceil((ymax - ymin) / resolution))
        self.log_odds = np.zeros((self.ny, self.nx), dtype=np.float32)
        self.occ_threshold = 0.0
        self.free_update = -0.4  # Log-odds decrease for free space
        self.occ_update = 0.7    # Log-odds increase for occupied space

    def world_to_cell(self, x, y):
        ix = int((x - self.xmin) / self.res)
        iy = int((y - self.ymin) / self.res)
        return ix, iy

    def cell_to_world(self, ix, iy):
        x = self.xmin + (ix + 0.5) * self.res
        y = self.ymin + (iy + 0.5) * self.res
        return x, y

    def bresenham_line(self, x0, y0, x1, y1):
        """Bresenham's line algorithm for ray tracing"""
        points = []
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        
        while True:
            points.append((x0, y0))
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy
        return points

    def integrate_scan(self, robot_pos, pts_world, z_min=0.02, z_max=2.0):
        """Integrate laser scan with ray tracing for proper SLAM"""
        mask = (pts_world[:, 2] > z_min) & (pts_world[:, 2] < z_max)
        pts = pts_world[mask]
        
        robot_ix, robot_iy = self.world_to_cell(robot_pos[0], robot_pos[1])
        
        for pnt in pts:
            pnt_ix, pnt_iy = self.world_to_cell(pnt[0], pnt[1])
            
            # Check bounds
            if not (0 <= pnt_ix < self.nx and 0 <= pnt_iy < self.ny):
                continue
            
            # Ray trace from robot to point
            line = self.bresenham_line(robot_ix, robot_iy, pnt_ix, pnt_iy)
            
            # Mark free cells along ray
            for (ix, iy) in line[:-1]:
                if 0 <= ix < self.nx and 0 <= iy < self.ny:
                    self.log_odds[iy, ix] = max(self.log_odds[iy, ix] + self.free_update, -5.0)
            
            # Mark occupied cell at endpoint
            if 0 <= pnt_ix < self.nx and 0 <= pnt_iy < self.ny:
                self.log_odds[pnt_iy, pnt_ix] = min(self.log_odds[pnt_iy, pnt_ix] + self.occ_update, 5.0)

    def get_occupancy(self):
        """Get binary occupancy grid"""
        return self.log_odds > self.occ_threshold
    
    def get_probability_grid(self):
        """Convert log-odds to probability [0, 1]"""
        return 1.0 / (1.0 + np.exp(-self.log_odds))

# -----------------------
# A* Path Planning
# -----------------------
import heapq

def astar(grid, start, goal, allow_diagonal=True):
    """A* pathfinding on 2D grid"""
    h = lambda a, b: math.hypot(b[0] - a[0], b[1] - a[1])
    dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if allow_diagonal:
        dirs += [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    
    open_heap = []
    came_from = {}
    gscore = {start: 0}
    fscore = {start: h(start, goal)}
    heapq.heappush(open_heap, (fscore[start], start))
    
    while open_heap:
        _, current = heapq.heappop(open_heap)
        if current == goal:
            path = []
            cur = current
            while cur != start:
                path.append(cur)
                cur = came_from[cur]
            path.append(start)
            path.reverse()
            return path
        
        for d in dirs:
            neighbor = (current[0] + d[0], current[1] + d[1])
            if not (0 <= neighbor[0] < grid.shape[1] and 0 <= neighbor[1] < grid.shape[0]):
                continue
            if not grid[neighbor[1], neighbor[0]]:
                continue
            
            tentative = gscore[current] + h(current, neighbor)
            if neighbor not in gscore or tentative < gscore[neighbor]:
                came_from[neighbor] = current
                gscore[neighbor] = tentative
                fscore[neighbor] = tentative + h(neighbor, goal)
                heapq.heappush(open_heap, (fscore[neighbor], neighbor))
    
    return None

# -----------------------
# ROS2 Node for Visualization
# -----------------------
if ROS_AVAILABLE:
    class SLAMVisualizerNode(Node):
        def __init__(self):
            super().__init__('slam_visualizer')
            
            # Publishers
            self.map_pub = self.create_publisher(OccupancyGrid, '/map', 10)
            self.path_pub = self.create_publisher(NavPath, '/planned_path', 10)
            self.odom_pub = self.create_publisher(Odometry, '/odom', 10)
            self.pointcloud_pub = self.create_publisher(PointCloud2, '/pointcloud', 10)
            self.image_pub = self.create_publisher(Image, '/camera/rgb/image', 10)
            self.marker_pub = self.create_publisher(MarkerArray, '/visualization_markers', 10)
            
            # TF broadcaster
            self.tf_broadcaster = TransformBroadcaster(self)
            
            # CV Bridge
            self.bridge = CvBridge()
            
            self.get_logger().info('SLAM Visualizer Node initialized')
        
        def publish_map(self, occ_map):
            """Publish occupancy grid to RViz"""
            msg = OccupancyGrid()
            msg.header = Header()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'map'
            
            msg.info = MapMetaData()
            msg.info.resolution = float(occ_map.res)
            msg.info.width = int(occ_map.nx)
            msg.info.height = int(occ_map.ny)
            msg.info.origin.position.x = float(occ_map.xmin)
            msg.info.origin.position.y = float(occ_map.ymin)
            msg.info.origin.position.z = 0.0
            msg.info.origin.orientation.w = 1.0
            
            # Convert to ROS occupancy format: -1 (unknown), 0 (free), 100 (occupied)
            prob_grid = occ_map.get_probability_grid()
            ros_grid = np.full((occ_map.ny, occ_map.nx), -1, dtype=np.int8)
            
            # Only mark cells that have been observed
            observed = np.abs(occ_map.log_odds) > 0.1
            ros_grid[observed] = (prob_grid[observed] * 100).astype(np.int8)
            
            msg.data = ros_grid.flatten().tolist()
            self.map_pub.publish(msg)
        
        def publish_path(self, waypoints):
            """Publish planned path to RViz"""
            msg = NavPath()
            msg.header = Header()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'map'
            
            for wp in waypoints:
                pose = PoseStamped()
                pose.header = msg.header
                pose.pose.position.x = float(wp[0])
                pose.pose.position.y = float(wp[1])
                pose.pose.position.z = 0.0
                pose.pose.orientation.w = 1.0
                msg.poses.append(pose)
            
            self.path_pub.publish(msg)
        
        def publish_odom(self, position, orientation):
            """Publish odometry"""
            msg = Odometry()
            msg.header = Header()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'map'
            msg.child_frame_id = 'base_link'
            
            msg.pose.pose.position.x = float(position[0])
            msg.pose.pose.position.y = float(position[1])
            msg.pose.pose.position.z = float(position[2])
            msg.pose.pose.orientation.x = float(orientation[0])
            msg.pose.pose.orientation.y = float(orientation[1])
            msg.pose.pose.orientation.z = float(orientation[2])
            msg.pose.pose.orientation.w = float(orientation[3])
            
            self.odom_pub.publish(msg)
            
            # Broadcast TF
            t = TransformStamped()
            t.header = msg.header
            t.child_frame_id = 'base_link'
            t.transform.translation.x = float(position[0])
            t.transform.translation.y = float(position[1])
            t.transform.translation.z = float(position[2])
            t.transform.rotation = msg.pose.pose.orientation
            
            self.tf_broadcaster.sendTransform(t)
        
        def publish_pointcloud(self, points):
            """Publish point cloud"""
            if len(points) == 0:
                return
            
            header = Header()
            header.stamp = self.get_clock().now().to_msg()
            header.frame_id = 'map'
            
            fields = [
                PointField(name='x', offset=0, datatype=PointField.FLOAT32, count=1),
                PointField(name='y', offset=4, datatype=PointField.FLOAT32, count=1),
                PointField(name='z', offset=8, datatype=PointField.FLOAT32, count=1),
            ]
            
            pc_msg = pc2.create_cloud(header, fields, points)
            self.pointcloud_pub.publish(pc_msg)
        
        def publish_image(self, rgb_image):
            """Publish RGB image"""
            msg = self.bridge.cv2_to_imgmsg(rgb_image, encoding='rgb8')
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'camera_link'
            self.image_pub.publish(msg)
        
        def publish_goal_marker(self, goal_pos):
            """Publish goal marker"""
            marker_array = MarkerArray()
            
            marker = Marker()
            marker.header = Header()
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.header.frame_id = 'map'
            marker.ns = 'goal'
            marker.id = 0
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            
            marker.pose.position.x = float(goal_pos[0])
            marker.pose.position.y = float(goal_pos[1])
            marker.pose.position.z = 0.5
            marker.pose.orientation.w = 1.0
            
            marker.scale.x = 0.3
            marker.scale.y = 0.3
            marker.scale.z = 0.3
            
            marker.color = ColorRGBA(r=1.0, g=0.0, b=0.0, a=1.0)
            
            marker_array.markers.append(marker)
            self.marker_pub.publish(marker_array)

# -----------------------
# Robot Controller
# -----------------------
class RobotController:
    def __init__(self, robot_id, client):
        self.robot_id = robot_id
        self.client = client
        self.autonomous_mode = False
        self.slam_recording = False
        self.waypoints = []
        self.current_waypoint_idx = 0
        
        # Get joint indices
        num_joints = p.getNumJoints(robot_id, physicsClientId=client)
        self.joints = {p.getJointInfo(robot_id, i, physicsClientId=client)[1].decode(): i 
                      for i in range(num_joints)}
        
        self.left_front = self.joints.get("left_front_joint")
        self.right_front = self.joints.get("right_front_joint")
        self.left_back = self.joints.get("left_back_joint")
        self.right_back = self.joints.get("right_back_joint")
        
        self.shoulder = self.joints.get("link1_joint")
        self.elbow = self.joints.get("link2_joint")
        self.wrist = self.joints.get("link3_joint")
        
        # Disable default motor forces
        for w in [self.left_front, self.right_front, self.left_back, self.right_back]:
            if w is not None:
                p.setJointMotorControl2(robot_id, w, p.VELOCITY_CONTROL, 
                                       targetVelocity=0, force=0, physicsClientId=client)
        
        # Control parameters
        self.wheel_speed = 6.0
        self.turn_speed = 3.0
        self.arm_speed = 0.02
        
        # Trajectory history
        self.trajectory = deque(maxlen=1000)
        
    def manual_control(self, keys):
        """Handle keyboard input for manual control"""
        move = 0
        rot = 0
        
        if ord('w') in keys and keys[ord('w')] & p.KEY_IS_DOWN:
            move = 1
        if ord('s') in keys and keys[ord('s')] & p.KEY_IS_DOWN:
            move = -1
        if ord('a') in keys and keys[ord('a')] & p.KEY_IS_DOWN:
            rot = 1
        if ord('d') in keys and keys[ord('d')] & p.KEY_IS_DOWN:
            rot = -1
        
        left_speed = (move * self.wheel_speed) + (rot * self.turn_speed)
        right_speed = (move * self.wheel_speed) - (rot * self.turn_speed)
        
        for w in [self.left_front, self.left_back]:
            if w is not None:
                p.setJointMotorControl2(self.robot_id, w, p.VELOCITY_CONTROL, 
                                       targetVelocity=left_speed, force=40, 
                                       physicsClientId=self.client)
        
        for w in [self.right_front, self.right_back]:
            if w is not None:
                p.setJointMotorControl2(self.robot_id, w, p.VELOCITY_CONTROL, 
                                       targetVelocity=right_speed, force=40, 
                                       physicsClientId=self.client)
        
        # Arm control
        if self.shoulder is not None:
            if ord('i') in keys and keys[ord('i')] & p.KEY_IS_DOWN:
                current_pos = p.getJointState(self.robot_id, self.shoulder, 
                                             physicsClientId=self.client)[0]
                p.setJointMotorControl2(self.robot_id, self.shoulder, p.POSITION_CONTROL,
                                       targetPosition=current_pos + self.arm_speed, 
                                       force=20, physicsClientId=self.client)
            if ord('k') in keys and keys[ord('k')] & p.KEY_IS_DOWN:
                current_pos = p.getJointState(self.robot_id, self.shoulder, 
                                             physicsClientId=self.client)[0]
                p.setJointMotorControl2(self.robot_id, self.shoulder, p.POSITION_CONTROL,
                                       targetPosition=current_pos - self.arm_speed, 
                                       force=20, physicsClientId=self.client)
        
        if self.elbow is not None:
            if ord('j') in keys and keys[ord('j')] & p.KEY_IS_DOWN:
                current_pos = p.getJointState(self.robot_id, self.elbow, 
                                             physicsClientId=self.client)[0]
                p.setJointMotorControl2(self.robot_id, self.elbow, p.POSITION_CONTROL,
                                       targetPosition=current_pos + self.arm_speed, 
                                       force=20, physicsClientId=self.client)
            if ord('l') in keys and keys[ord('l')] & p.KEY_IS_DOWN:
                current_pos = p.getJointState(self.robot_id, self.elbow, 
                                             physicsClientId=self.client)[0]
                p.setJointMotorControl2(self.robot_id, self.elbow, p.POSITION_CONTROL,
                                       targetPosition=current_pos - self.arm_speed, 
                                       force=20, physicsClientId=self.client)
        
        if self.wrist is not None:
            if ord('u') in keys and keys[ord('u')] & p.KEY_IS_DOWN:
                current_pos = p.getJointState(self.robot_id, self.wrist, 
                                             physicsClientId=self.client)[0]
                p.setJointMotorControl2(self.robot_id, self.wrist, p.POSITION_CONTROL,
                                       targetPosition=current_pos + self.arm_speed, 
                                       force=20, physicsClientId=self.client)
            if ord('o') in keys and keys[ord('o')] & p.KEY_IS_DOWN:
                current_pos = p.getJointState(self.robot_id, self.wrist, 
                                             physicsClientId=self.client)[0]
                p.setJointMotorControl2(self.robot_id, self.wrist, p.POSITION_CONTROL,
                                       targetPosition=current_pos - self.arm_speed, 
                                       force=20, physicsClientId=self.client)
    
    def set_waypoints(self, waypoints):
        """Set waypoints for autonomous navigation"""
        self.waypoints = waypoints
        self.current_waypoint_idx = 0
    
    def autonomous_navigation(self):
        """Execute autonomous navigation to waypoints"""
        if not self.waypoints or self.current_waypoint_idx >= len(self.waypoints):
            return False
        
        target_wp = self.waypoints[self.current_waypoint_idx]
        base_pos, base_orn = p.getBasePositionAndOrientation(self.robot_id, 
                                                             physicsClientId=self.client)
        
        dx = target_wp[0] - base_pos[0]
        dy = target_wp[1] - base_pos[1]
        distance = math.hypot(dx, dy)
        
        if distance < 0.2:  # Reached waypoint
            self.current_waypoint_idx += 1
            print(f"Reached waypoint {self.current_waypoint_idx}/{len(self.waypoints)}")
            return True
        
        # Simple proportional controller
        target_yaw = math.atan2(dy, dx)
        _, _, current_yaw = quat_to_euler(base_orn)
        
        yaw_error = target_yaw - current_yaw
        # Normalize angle
        while yaw_error > math.pi:
            yaw_error -= 2 * math.pi
        while yaw_error < -math.pi:
            yaw_error += 2 * math.pi
        
        # Control velocities
        forward_vel = min(distance * 2.0, self.wheel_speed)
        turn_vel = yaw_error * 2.0
        
        left_speed = forward_vel + turn_vel
        right_speed = forward_vel - turn_vel
        
        for w in [self.left_front, self.left_back]:
            if w is not None:
                p.setJointMotorControl2(self.robot_id, w, p.VELOCITY_CONTROL, 
                                       targetVelocity=left_speed, force=40, 
                                       physicsClientId=self.client)
        
        for w in [self.right_front, self.right_back]:
            if w is not None:
                p.setJointMotorControl2(self.robot_id, w, p.VELOCITY_CONTROL, 
                                       targetVelocity=right_speed, force=40, 
                                       physicsClientId=self.client)
        
        return True
    
    def update_trajectory(self):
        """Record current position for trajectory visualization"""
        base_pos, _ = p.getBasePositionAndOrientation(self.robot_id, 
                                                       physicsClientId=self.client)
        self.trajectory.append((base_pos[0], base_pos[1]))

# -----------------------
# Main Application
# -----------------------
def main():
    parser = argparse.ArgumentParser(description='Enhanced SLAM with RViz Visualization')
    parser.add_argument('--urdf', type=str, 
                       default=os.path.expanduser("~/arm_mobile/src/mobile_arm/urdf/mobile.urdf"),
                       help='Path to robot URDF file')
    parser.add_argument('--goal', type=float, nargs=3, default=[5.0, 2.0, 0],
                       help='Goal position: x y yaw (meters, radians)')
    parser.add_argument('--out', type=str, default='/tmp/robot_slam',
                       help='Output directory for recordings')
    parser.add_argument('--box-size', type=float, default=0.15,
                       help='Size of graspable boxes (meters)')
    parser.add_argument('--no-gui', action='store_true',
                       help='Run without PyBullet GUI')
    args = parser.parse_args()
    
    # Initialize ROS2
    ros_node = None
    if ROS_AVAILABLE:
        rclpy.init()
        ros_node = SLAMVisualizerNode()
        print("✓ ROS2 visualization enabled")
    
    # Initialize PyBullet
    client = p.connect(p.GUI if not args.no_gui else p.DIRECT)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.resetSimulation(physicsClientId=client)
    p.setGravity(0, 0, -9.8, physicsClientId=client)
    p.loadURDF("plane.urdf", physicsClientId=client)
    
    if not args.no_gui:
        p.resetDebugVisualizerCamera(cameraDistance=12, cameraYaw=50, 
                                     cameraPitch=-30, cameraTargetPosition=[0, 0, 0])
    
    # Load robot
    startPos = [0, 0, 0.05]
    startOri = p.getQuaternionFromEuler([0, 0, 0])
    robot_id = p.loadURDF(args.urdf, startPos, startOri, useFixedBase=False, 
                         physicsClientId=client)
    
    # Create environment
    print(f"Creating environment with graspable box size: {args.box_size}m")
    graspable_objects = create_room_env(client, graspable_box_size=args.box_size)
    print(f"Created {len(graspable_objects)} graspable objects")
    
    # Initialize controller
    controller = RobotController(robot_id, client)
    
    # Initialize mapping
    img_w, img_h = 320, 240
    intrinsics = {
        'fx': 0.5 * img_w / math.tan(math.radians(60) / 2),
        'fy': 0.5 * img_h / math.tan(math.radians(60) / 2),
        'cx': img_w / 2.0,
        'cy': img_h / 2.0
    }
    occ_map = OccupancyMap2D(xmin=-10, xmax=10, ymin=-10, ymax=10, resolution=0.1)
    
    # Output directory
    from pathlib import Path as PathLib
    outdir = PathLib(args.out)
    outdir.mkdir(parents=True, exist_ok=True)
    
    # Goal position
    current_goal = args.goal
    
    print("\n" + "="*70)
    print("Enhanced SLAM with RViz Visualization")
    print("="*70)
    print("\n🎮 KEYBOARD CONTROLS:")
    print("  ┌─────────────────────────────────────────────────────────┐")
    print("  │ MOVEMENT (Manual Mode)                                  │")
    print("  │  W/S     - Move forward/backward                        │")
    print("  │  A/D     - Turn left/right                              │")
    print("  ├─────────────────────────────────────────────────────────┤")
    print("  │ ARM CONTROL                                             │")
    print("  │  I/K     - Shoulder joint up/down                       │")
    print("  │  J/L     - Elbow joint up/down                          │")
    print("  │  U/O     - Wrist joint up/down                          │")
    print("  ├─────────────────────────────────────────────────────────┤")
    print("  │ SLAM & NAVIGATION                                       │")
    print("  │  R       - Toggle SLAM recording (map while driving!)   │")
    print("  │  V       - Save and visualize current map               │")
    print("  │  G       - Plan path to goal with current map           │")
    print("  │  M       - Toggle autonomous mode                       │")
    print("  │  Q       - Quit                                         │")
    print("  └─────────────────────────────────────────────────────────┘")
    print("\n📋 WORKFLOW:")
    print("  1️⃣  Press 'R' to start SLAM recording")
    print("  2️⃣  Drive around with W/A/S/D to map the environment")
    print("  3️⃣  Press 'V' to save and view the map")
    print("  4️⃣  Press 'G' to plan a path to the goal")
    print("  5️⃣  Press 'M' to enable autonomous navigation")
    print("\n⚠️  IMPORTANT: SLAM records while YOU drive with WASD keys!")
    print("="*70)
    print(f"\n📁 Output directory: {outdir}")
    print(f"🎯 Current goal: ({current_goal[0]:.2f}, {current_goal[1]:.2f})")
    print(f"📦 Graspable box size: {args.box_size}m")
    print("\n")
    
    frame_count = 0
    last_map_update = 0
    map_update_interval = 5  # Update map every N frames during SLAM
    last_ros_publish = 0
    ros_publish_interval = 10  # Publish to ROS every N frames
    last_status_update = 0
    status_update_interval = 60  # Update status message every N frames
    
    try:
        while True:
            keys = p.getKeyboardEvents()
            
            # Check for quit
            if ord('q') in keys and keys[ord('q')] & p.KEY_WAS_TRIGGERED:
                break
            
            # Toggle SLAM recording
            if ord('r') in keys and keys[ord('r')] & p.KEY_WAS_TRIGGERED:
                controller.slam_recording = not controller.slam_recording
                if controller.slam_recording:
                    print("\n" + "="*70)
                    print("🔴 SLAM RECORDING STARTED")
                    print("="*70)
                    print("Drive around using W/A/S/D keys to map the environment!")
                    print("The map will update automatically as you move.")
                    print("Press 'R' again to stop recording.")
                    print("="*70 + "\n")
                    occ_map = OccupancyMap2D(xmin=-10, xmax=10, ymin=-10, ymax=10, resolution=0.1)
                else:
                    print("\n⏹️  SLAM recording STOPPED\n")
            
            # Toggle autonomous mode
            if ord('m') in keys and keys[ord('m')] & p.KEY_WAS_TRIGGERED:
                controller.autonomous_mode = not controller.autonomous_mode
                if controller.autonomous_mode:
                    if len(controller.waypoints) == 0:
                        print("⚠️  No path planned! Press G to plan path first.")
                        controller.autonomous_mode = False
                    else:
                        print("🤖 Autonomous navigation ENABLED")
                else:
                    print("🎮 Manual mode ENABLED")
            
            # Plan path to goal
            if ord('g') in keys and keys[ord('g')] & p.KEY_WAS_TRIGGERED:
                print("\n📍 Planning path to goal...")
                
                base_pos, base_orn = p.getBasePositionAndOrientation(robot_id, 
                                                                     physicsClientId=client)
                start_world = (base_pos[0], base_pos[1])
                goal_world = (current_goal[0], current_goal[1])
                
                s_ix, s_iy = occ_map.world_to_cell(*start_world)
                g_ix, g_iy = occ_map.world_to_cell(*goal_world)
                
                s_ix = np.clip(s_ix, 0, occ_map.nx - 1)
                s_iy = np.clip(s_iy, 0, occ_map.ny - 1)
                g_ix = np.clip(g_ix, 0, occ_map.nx - 1)
                g_iy = np.clip(g_iy, 0, occ_map.ny - 1)
                
                occ_grid = occ_map.get_occupancy()
                free_grid = ~occ_grid
                
                # Check if positions are valid
                if not free_grid[s_iy, s_ix]:
                    print(f"⚠️  Warning: Start position appears occupied in map")
                    print(f"   This may be due to limited map coverage.")
                if not free_grid[g_iy, g_ix]:
                    print(f"⚠️  Warning: Goal position appears occupied!")
                    print(f"   You may need to choose a different goal or map more area.")
                
                # Try to find path anyway
                path = astar(free_grid, (s_ix, s_iy), (g_ix, g_iy), allow_diagonal=True)
                
                if path is None:
                    print("❌ No path found!")
                    print("   Try:")
                    print("   - Press 'R' and drive around to map more area")
                    print("   - Choose a different goal position")
                    print("   - Press 'V' to visualize what's been mapped")
                else:
                    waypoints = []
                    for cell in path[::5]:  # Subsample path
                        x, y = occ_map.cell_to_world(cell[0], cell[1])
                        waypoints.append((x, y))
                    
                    controller.set_waypoints(waypoints)
                    
                    # Save path
                    with open(outdir / 'path.json', 'w') as f:
                        json.dump({'path': waypoints, 'goal': current_goal}, f, indent=2)
                    
                    print(f"✅ Path planned with {len(waypoints)} waypoints")
                    print(f"   Saved to {outdir / 'path.json'}")
                    print(f"   Press 'M' to start autonomous navigation!")
                    
                    # Publish to ROS
                    if ros_node:
                        ros_node.publish_path(waypoints)
                        ros_node.publish_goal_marker(goal_world)
                print()
            
            # Save and visualize map
            if ord('v') in keys and keys[ord('v')] & p.KEY_WAS_TRIGGERED:
                print("Saving and visualizing map...")
                
                # Save occupancy grid
                occ_grid = occ_map.get_occupancy()
                prob_grid = occ_map.get_probability_grid()
                
                np.save(outdir / "occupancy_binary.npy", occ_grid)
                np.save(outdir / "occupancy_prob.npy", prob_grid)
                
                # Create visualization image
                vis_img = (prob_grid * 255).astype(np.uint8)
                vis_img = cv2.cvtColor(vis_img, cv2.COLOR_GRAY2BGR)
                
                # Draw robot position
                base_pos, _ = p.getBasePositionAndOrientation(robot_id, physicsClientId=client)
                robot_ix, robot_iy = occ_map.world_to_cell(base_pos[0], base_pos[1])
                cv2.circle(vis_img, (robot_ix, occ_map.ny - robot_iy), 5, (0, 255, 0), -1)
                
                # Draw goal
                goal_ix, goal_iy = occ_map.world_to_cell(current_goal[0], current_goal[1])
                cv2.circle(vis_img, (goal_ix, occ_map.ny - goal_iy), 5, (0, 0, 255), -1)
                
                # Draw trajectory
                for i in range(1, len(controller.trajectory)):
                    p1 = controller.trajectory[i-1]
                    p2 = controller.trajectory[i]
                    ix1, iy1 = occ_map.world_to_cell(p1[0], p1[1])
                    ix2, iy2 = occ_map.world_to_cell(p2[0], p2[1])
                    cv2.line(vis_img, (ix1, occ_map.ny - iy1), 
                            (ix2, occ_map.ny - iy2), (255, 0, 0), 1)
                
                cv2.imwrite(str(outdir / "map_visualization.png"), vis_img)
                print(f"✓ Map saved to {outdir}")
                print(f"  - occupancy_binary.npy")
                print(f"  - occupancy_prob.npy")
                print(f"  - map_visualization.png")
                
                # Publish to ROS
                if ros_node:
                    ros_node.publish_map(occ_map)
                    print("✓ Map published to RViz on /map topic")
            
            # SLAM: Continuous mapping while recording
            if controller.slam_recording and (frame_count - last_map_update) >= map_update_interval:
                try:
                    base_pos, base_orn = p.getBasePositionAndOrientation(robot_id, 
                                                                         physicsClientId=client)
                    
                    rgb, depth, seg, cam_pose = get_camera_image_from_link(
                        client, robot_id, 'container_camera_link', 
                        img_w=img_w, img_h=img_h)
                    
                    pts_cam = depth_to_pointcloud(depth, intrinsics)
                    pts_world = transform_pointcloud(pts_cam, cam_pose)
                    
                    # Integrate with ray tracing
                    occ_map.integrate_scan(base_pos, pts_world)
                    
                    last_map_update = frame_count
                    
                    # Save frames periodically
                    if frame_count % 60 == 0:
                        fname = outdir / f"slam_{frame_count:06d}.png"
                        cv2.imwrite(str(fname), cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
                    
                    # Publish to ROS
                    if ros_node and (frame_count - last_ros_publish) >= ros_publish_interval:
                        ros_node.publish_image(rgb)
                        ros_node.publish_pointcloud(pts_world)
                        last_ros_publish = frame_count
                        
                except Exception as e:
                    if frame_count % 240 == 0:  # Print error occasionally
                        print(f"⚠️  Camera capture error: {e}")
            
            # Update trajectory
            if frame_count % 10 == 0:
                controller.update_trajectory()
            
            # Execute control
            if controller.autonomous_mode:
                still_navigating = controller.autonomous_navigation()
                if not still_navigating:
                    print("✓ Navigation complete!")
                    controller.autonomous_mode = False
            else:
                controller.manual_control(keys)
            
            # Publish odometry to ROS
            if ros_node and frame_count % 5 == 0:
                base_pos, base_orn = p.getBasePositionAndOrientation(robot_id, 
                                                                     physicsClientId=client)
                ros_node.publish_odom(base_pos, base_orn)
            
            # Step simulation
            p.stepSimulation(physicsClientId=client)
            
            # Spin ROS
            if ros_node:
                rclpy.spin_once(ros_node, timeout_sec=0)
            
            frame_count += 1
            time.sleep(1./240.)
    
    except KeyboardInterrupt:
        print("\n\n⏹️  Shutting down...")
    
    finally:
        # Save final state
        print("\nSaving final data...")
        
        base_pos, base_orn = p.getBasePositionAndOrientation(robot_id, physicsClientId=client)
        final_state = {
            'position': list(base_pos),
            'orientation': list(base_orn),
            'euler': list(quat_to_euler(base_orn)),
            'trajectory_length': len(controller.trajectory),
            'frames_recorded': frame_count
        }
        
        with open(outdir / 'final_state.json', 'w') as f:
            json.dump(final_state, f, indent=2)
        
        # Save trajectory
        traj_array = np.array(list(controller.trajectory))
        if len(traj_array) > 0:
            np.save(outdir / 'trajectory.npy', traj_array)
            print(f"✓ Trajectory saved ({len(traj_array)} points)")
        
        # Save final map
        occ_grid = occ_map.get_occupancy()
        np.save(outdir / 'final_map.npy', occ_grid)
        
        print(f"✓ Final state saved to {outdir}")
        print(f"  Total frames: {frame_count}")
        
        if ros_node:
            ros_node.destroy_node()
            rclpy.shutdown()
        
        p.disconnect(client)
        print("\n👋 Cleanup complete. Goodbye!\n")


if __name__ == "__main__":
    main()